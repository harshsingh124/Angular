import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoiceListComponent } from './invoice-list/invoice-list.component';
import { InvoiceFormComponent } from './invoice-form/invoice-form.component';



@NgModule({
  declarations: [
   
  ],
  imports: [
    CommonModule
  ]
})
export class InvoiceModule { }
